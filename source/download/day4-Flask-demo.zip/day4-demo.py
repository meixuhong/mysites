from flask import Flask,render_template
from flask_script import Manager

app = Flask(__name__)
manager = Manager(app)

@app.route('/')
def index():
    return render_template('hello-6.html', name='<em>flask</em>')

@app.route('/hello')
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello-6.html', name=name)

if __name__ == '__main__':
    manager.run()