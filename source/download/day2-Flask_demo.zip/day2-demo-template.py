from flask import Flask,render_template,url_for
from flask_script import Manager

# __name__表示的是本模块demo.py,定义一个Flask对象,传入参数是demo.py
app = Flask(__name__)
# 定义一个Manager对象，使用扩展工具Manager管理Flask对象
manager = Manager(app)

# 定义全局变量user和movies
user1 = {
    'username': 'Mei',
    'bio': 'A boy who loves movies and music.',
}

movies1 = [
    {'name': 'My Neighbor Totoro', 'year': '1988'},
    {'name': 'Three Colours trilogy', 'year': '1993'},
    {'name': 'Forrest Gump', 'year': '1994'},
    {'name': 'Perfect Blue', 'year': '1997'},
    {'name': 'The Matrix', 'year': '1999'},
    {'name': 'Memento', 'year': '2000'},
    {'name': 'The Bucket list', 'year': '2007'},
    {'name': 'Black Swan', 'year': '2010'},
    {'name': 'Gone Girl', 'year': '2014'},
    {'name': 'CoCo', 'year': '2017'},
]

# 定义路由
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/movies')
def movies():
    # user与movies是传递给模板watchlist.html中的变量，user1与movies1是上面定义的全局变量值
    return render_template('watchlist.html',user = user1, movies = movies1)    

# 使用url_for做反转url
@app.route('/user')
def user_view():
    return url_for('index',_external=True)    

@app.route('/mei/login/<id>/')
def login(id):
    # print(id)
    return render_template('index.html')

if __name__ == "__main__":
    manager.run()